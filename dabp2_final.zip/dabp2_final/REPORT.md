# Project 2 report

# Introduction
This application consists of a Deno-based backend and a React frontend with ViteJS. Despite of my greatest efforts, I couldn't make the whole app run on one command. However, the backend can be run with ```docker compose up --build``` from the root folder and the frontend with ```deno task dev``` from the frontend folder. Please note that you need to have Deno installed on your machine to run the frontend. The tests are done with k6 and can be run with ```k6 run {test_name}``` in the test folder.

# Core Web Vitals
| Performance | Accessibility | Best Practises | SEP |
|-------------|---------------|----------------|-----|
| 80          | 100           | 100            | 89  |

# Performance tests
API:
| Median | 95th Percentile | 99th Percentile |
|--------|-----------------|-----------------|
| 9.8s   | 34.42s          | 37.39s          |

Main page:

| Median | 95th Percentile | 99th Percentile |
|--------|-----------------|-----------------|
| 21.5ms | 83.77ms         | 145.26ms        |

# Performance Reflection
The results of the core web vitals tests were quite pleasant. However, it is pretty easy to achieve this kind of performance with a simple React app. Although the frontend works swiftly, the backend performance is pretty poor. There are different reasons for the backend performance. For example, the "grader" takes a lot of time to boot up and consumes a lot of memory, so not very many instances can be run in parallel. The queue implementation also introduces a timeout for each submission, which slows things down.

# Suggestions for improving performance
As mentioned above, it would be easiest to seek performance improvements from the backend. The biggest improvements would propably come from improving the grading by either adding more resources, or more intelligently, making the grading process faster and more resource-friendly. The backend would also benefit from a more sophisticated queue implementation and better connection handling, such as using web sockets. Of course, the frontend performance is not 100, so e.g., rendering more of the content server-side might increase performance as well. Lastly, the Docker configuration also causes some overhead, so creating a tailored solution without docker would give some performance benefits.