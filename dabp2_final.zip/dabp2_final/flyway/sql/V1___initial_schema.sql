CREATE TABLE exercises (
    uuid TEXT PRIMARY KEY,
    one TEXT,
    two TEXT,
    three TEXT,
    four TEXT,
    five TEXT,
    six TEXT,
    seven TEXT,
    eight TEXT,
    nine TEXT
);

CREATE TABLE results (
    uuid TEXT PRIMARY KEY,
    one TEXT,
    two TEXT,
    three TEXT,
    four TEXT,
    five TEXT,
    six TEXT,
    seven TEXT,
    eight TEXT,
    nine TEXT
);


INSERT INTO exercises
  ("uuid", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine") 
  VALUES 
  ('testaaja', 'testi1', 'testi2', 'testi3', 'testi4', 'testi5', 'testi6', 'testi7', 'testi8', 'testi9');



  INSERT INTO results
  ("uuid", "one", "three", "six") 
  VALUES 
  ('testaaja', 'PASS', 'FAIL', 'ERROR');
