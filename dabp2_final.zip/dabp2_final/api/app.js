import { Application, Router } from "https://deno.land/x/oak@v11.1.0/mod.ts";
import { grade } from "./grade.js";
import { oakCors } from "https://deno.land/x/cors@v1.2.2/mod.ts";
import { Pool } from "https://deno.land/x/postgres@v0.17.0/mod.ts";

let currentConnections = 0

const app = new Application()
const router = new Router()

function updateAnswers(old, number, code) {
  let newAnswers = old.rows[0]
  switch (number) {
    case "one":
      newAnswers.one = code
      break;
    case "two":
      newAnswers.two = code
      break;
    case "three":
      newAnswers.three = code
      break;
    case "four":
      newAnswers.four = code
      break;   
    case "five":
      newAnswers.five = code
      break; 
    case "six":
      newAnswers.six = code
      break;   
    case "seven":
      newAnswers.seven = code
      break;
    case "eight":
      newAnswers.eight = code
      break;   
    case "nine": 
      newAnswers.nine = code
      }
      return newAnswers
}

router.post("/", async (ctx) => {
  const body = await ctx.request.body({ type: 'text'});
  const formData = await body;
  const code = formData.code

  setTimeout(Math.random()*60000)

  /*currentConnections += 1
  while (currentConnections > 10) {
    setTimeout(100)
  }*/
  //currentConnections -= 1
  const result = await grade(code)

  ctx.response.body = (JSON.stringify({result:result}))
})

router.put("/submit", async (ctx) => {
  const CONCURRENT_CONNECTIONS = 10;
  const connectionPool = new Pool({}, CONCURRENT_CONNECTIONS);
  const url = new URL(ctx.request.url);
  const uuid = url.searchParams.get("uuid")
  const exercise = url.searchParams.get("exercise")
  const code = url.searchParams.get("code")
  const result = url.searchParams.get("result")
  console.log("code: " + code + " uuid: " + uuid + " exercise: " + exercise + " result: " + result)
  const client = await connectionPool.connect();
  
  let existingResults = await client.queryObject(`SELECT * FROM exercises WHERE "uuid" = '${uuid}'`)

  if (existingResults.rows[0]) {
    const exercisesQueryString = `UPDATE exercises SET "${exercise}" = '${code}' WHERE "uuid" = '${uuid}';`
    const resultsQueryString = `UPDATE results SET "${exercise}" = '${result}' WHERE "uuid" = '${uuid}';`
    await client.queryObject(exercisesQueryString);
    await client.queryObject(resultsQueryString);
    await client.release();
  } else {
    const exercisesQueryString = `INSERT INTO exercises ("${exercise}", "uuid" ) VALUES ('${code}', '${uuid}');`
    const resultsQueryString = `INSERT INTO results ("${exercise}", "uuid" ) VALUES ('${result}', '${uuid}');`
    await client.queryObject(exercisesQueryString);
    await client.queryObject(resultsQueryString);
    await client.release();
  }
})

router.get("/exercises", async (ctx) => {
  const CONCURRENT_CONNECTIONS = 10;
  const connectionPool = new Pool({}, CONCURRENT_CONNECTIONS);
  const url = new URL(ctx.request.url);
  const uuid = url.searchParams.get("uuid")
  const client = await connectionPool.connect();
  
  let existingResults = await client.queryObject(`SELECT * FROM exercises WHERE "uuid" = '${uuid}'`)
  if (existingResults.rows[0]) {
    ctx.response.body = JSON.stringify(existingResults.rows[0]);
  } else {
    ctx.response.body = JSON.stringify({
      "uuid": `${uuid}`,
      "one": null,
      "two": null,
      "three": null,
      "four": null,
      "five": null,
      "six": null,
      "seven": null,
      "eight": null,
      "nine": null
  });
  }
})

router.get("/results", async (ctx) => {
  const CONCURRENT_CONNECTIONS = 10;
  const connectionPool = new Pool({}, CONCURRENT_CONNECTIONS);
  const url = new URL(ctx.request.url);
  const uuid = url.searchParams.get("uuid")
  const client = await connectionPool.connect();
  
  let existingResults = await client.queryObject(`SELECT * FROM results WHERE "uuid" = '${uuid}'`)
  if (existingResults.rows[0]) {
    ctx.response.body = JSON.stringify(existingResults.rows[0]);
  } else {
    ctx.response.body = JSON.stringify({
      "uuid": `${uuid}`,
      "one": null,
      "two": null,
      "three": null,
      "four": null,
      "five": null,
      "six": null,
      "seven": null,
      "eight": null,
      "nine": null
  });
  }
})

app.use(oakCors());
app.use(router.routes())
app.use(router.allowedMethods())


app.listen({port: 7777})
