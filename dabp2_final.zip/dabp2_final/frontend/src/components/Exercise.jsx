import React, { useEffect, useState } from "react";

const Exercise = ({header, contents, waitingForGrading, setWaitingForGrading, dbExercises, setDbExercises, dbResults, setDbResults, number, uuid, result, fetchResults}) => {
   
    const toNumberString = (number) => {
        switch (number) {
            case 1:    
            return "one"
            case 2:    
            return "two"
            case 3:    
            return "three"
            case 4:    
            return "four"
            case 5:    
            return "five"
            case 6:    
            return "six"
            case 7:    
            return "seven"
            case 8:    
            return "eight"
            case 9:    
            return "nine"    
        }
    }

    const [showDetails, setShowDetails] = useState(false)
    const [answer, setAnswer] = useState("")
    //const [status, setStatus] = useState(dbResults[toNumberString(number)])
    const showButtonhandler = (e) => {
        e.preventDefault()
        setShowDetails(!showDetails)
    }

  const requestOptions = {
    method: 'POST',
    body: {code: answer},
    mode: "no-cors"
};

const getResult = async () => {
    setWaitingForGrading(true)
    const options = ["PASS", "FAIL", "ERROR"]
    const res = await fetch(`http://localhost:7777`, requestOptions)
    const passing = options[Math.floor(Math.random()*2)]
    await fetch(`http://localhost:7777/submit?uuid=${uuid}&exercise=${toNumberString(number)}&code=${answer}&result=${passing}`, {method: 'PUT'})
    console.log(res)
    setWaitingForGrading(false)
    fetchResults()
    //setStatus(passing)
  }

    return (
        <div>
            <h1>{header}</h1>
            <button onClick={showButtonhandler}>show</button>
            <br></br>
            {showDetails &&
            <div>
                <h3>{contents}</h3>
                <br></br>
                <textarea
                    placeholder={"answer"}
                    id={"answerInput"}
                    name={"answer"}
                    value={answer}
                    onChange={({target}) => setAnswer(target.value)}>
                </textarea>
                <br>
                </br>
                <button
                type={"submit"}
                onClick={() =>  {
                            getResult()
                            //setAnswer("")
                }}>
                    submit
                </button>
                <br></br>
                {result}
            </div>
            }
        </div>
    )
}
export default Exercise