import {
  require_react
} from "./chunk-BJFMU22U.js";
export default require_react();
//# sourceMappingURL=react.js.map
