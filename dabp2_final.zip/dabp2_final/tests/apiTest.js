import http from "k6/http";
export const options = {
 duration: "10s",
 vus: 30,
 summaryTrendStats: ["med", "p(95)", "p(99)"],
/* scenarios : {
 contacts: {
    gracefulStop: '180s',
    executor: 'constant-vus',
      vus: 30,
      duration: '10s',
}
}*/
};

export default function () {
http.post("http://localhost:7777") 
http.put("http://localhost:7777/submit?uuid=testuuid&exercise=one&code=ghghgh&result=FAIL" );
}